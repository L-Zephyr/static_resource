___FILEHEADER___

import UIKit
import RxSwift
import RxCocoa

class ___VARIABLE_productName:identifier___ViewController: UIViewController, View {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func doBinding(_ vm: ___VARIABLE_productName:identifier___ViewModel) {
        // Rx事件绑定
    }
}
