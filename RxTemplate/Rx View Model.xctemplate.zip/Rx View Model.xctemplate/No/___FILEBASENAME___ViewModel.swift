___FILEHEADER___

import Foundation
import RxSwift
import RxCocoa

// MARK: - ___FILEBASENAME___State

struct ___VARIABLE_productName:identifier___State: StateType {
    <#定义状态变量#>
}

// MARK: - Rx Export

extension Reactive where Base: ___FILEBASENAME___ {
    <#将状态转换成可观察的对象#>
}

// MARK: - ___FILEBASENAME___ViewModel

class ___FILEBASENAME___: Store<___VARIABLE_productName:identifier___State> {
    required public init(state: ___VARIABLE_productName:identifier___State) {
        super.init(state: state)
    }
    
}
